

<?php $__env->startSection('title',"Dashboard"); ?>

<?php $__env->startSection('content'); ?>
    <section style="min-height:600px">
        <div class="p-3 boxshadowgernet backbluelight">
                <ul class=" d-flex align-items-center mb-0 list-unstyled">
                    <li class="font500 font13">
                        <a href="<?php echo e(route('roles.index')); ?>">Back</a>
                        
                    </li>
                    <li class="mx-2">
                        <img src="<?php echo e(asset('public/assets/rightarrow.png')); ?>" alt="">
                    </li>
                    <li class="colorblue font500 font13 ms-4">
                        Admin Setting  
                    </li>
                    <li class="mx-2">
                        <img src="<?php echo e(asset('public/assets/rightarrow.png')); ?>" alt="">
                    </li>
                    <li class="font13 font500">Cerate Role</li>
                </ul>
        </div>

        <div class="boxhalf mt-3 boxshadowgernet">
            <div class="card-header">
               New Role Create
              </div>
            <div class="card">
                <div class="card-body">
                    <?php echo Form::open(array('route' => 'roles.store','method'=>'POST','class' => 'row g-3')); ?>

                        <div class="col-md-6">
                          <label for="inputEmail4" class="form-label">Role Name</label>
                          <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

                        </div>
                        <div class="col-md-6"></div>
                        <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3">
                            <div class="form-check">
                                <label><?php echo e(Form::checkbox('permission[]', $value->id, false, array('class' => 'name'))); ?>

                                    <?php echo e(Str::ucfirst($value->name)); ?></label>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u717518117/domains/liquorroad.in/public_html/admin/resources/views/roles/add_role.blade.php ENDPATH**/ ?>