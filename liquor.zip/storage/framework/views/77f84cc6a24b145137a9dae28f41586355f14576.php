<?php $__env->startSection('title',"Roles"); ?>

<?php $__env->startSection('content'); ?>
<div class="p-3 boxshadowgernet backbluelight">
    <ul class=" d-flex align-items-center mb-0 list-unstyled">
        <li class="font500 font13">
            <a href="<?php echo e(route('users.index')); ?>">Back</a>
        </li>
        <li class="mx-2">
            <img src="<?php echo e(asset('public/assets/rightarrow.png')); ?>" alt="">
        </li>
        <li class="colorblue font500 font13 ms-4">
            Admin Setting  
        </li>
        <li class="mx-2">
            <img src="<?php echo e(asset('public/assets/rightarrow.png')); ?>" alt="">
        </li>
        <li class="font13 font500">Manage Users</li>
    </ul>
</div>

<div class="p-4">

    <?php echo Form::model($user, ['method' => 'PATCH','route' => ['users.update', $user->id],'class'=>'row g-3']); ?>


    <div class="col-md-6">
        <label for="name" class="form-label">Name</label>
        <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

    </div>
    <div class="col-md-6">
        <label for="email" class="form-label">Email</label>
        <?php echo Form::text('email', null, array('placeholder' => 'Email','class' => 'form-control')); ?>

    </div>

    <div class="col-md-6">
        <label for="password" class="form-label">Password:</label>
        <?php echo Form::password('password', array('placeholder' => 'Password','class' => 'form-control')); ?>

    </div>
    <div class="col-md-6">
        <label for="confirm-password" class="form-label">Confirm Password:</label>
        <?php echo Form::password('confirm-password', array('placeholder' => 'Confirm Password','class' => 'form-control')); ?>

    </div>
    <div class="col-xs-6 col-sm-6 col-md-6">
        <label for="role" class="form-label">Role:</label>
        <?php echo Form::select('roles[]', $roles,$userRole, array('class' => 'form-control','multiple')); ?>

    </div>
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>
<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u717518117/domains/liquorroad.in/public_html/admin/resources/views/users/edit.blade.php ENDPATH**/ ?>