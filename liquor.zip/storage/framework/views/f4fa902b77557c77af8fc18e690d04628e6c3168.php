<?php $__env->startSection('title',"User Details"); ?>

<?php $__env->startSection('content'); ?>
    <section style="min-height:600px">
        <div class="p-3 boxshadowgernet backbluelight">
                <ul class=" d-flex align-items-center mb-0 list-unstyled">
                    <li class="font500 font13">
                        <a href="<?php echo e(route('users.index')); ?>">Back</a>
                        
                    </li>
                    <li class="mx-2">
                        <img src="<?php echo e(asset('public/assets/rightarrow.png')); ?>" alt="">
                    </li>
                    <li class="colorblue font500 font13 ms-4">
                        Admin Setting  
                    </li>
                    <li class="mx-2">
                        <img src="<?php echo e(asset('public/assets/rightarrow.png')); ?>" alt="">
                    </li>
                    <li class="font13 font500">View User Details</li>
                </ul>
        </div>

        <div class="boxhalf mt-3 boxshadowgernet">
            <div class="card-header">
               User Details
              </div>
            <div class="card">
                <div class="card-body">
                    <form class="row g-3">
                        <div class="col-md-12">
                          <label for="user" class="form-label">Name : <a href="#" class=""><?php echo e($user->name); ?></a></label>
                        </div>
                        <div class="col-md-12">
                          <label for="user" class="form-label">Email : <a href="#" class=""><?php echo e($user->email); ?></a></label>
                        </div>
                       
                        <div class="col-md-12">
                          <label for="roles" class="form-label">Roles : </label>
                        </div>
                        <?php if(!empty($user->getRoleNames())): ?>
                            <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <label class="form-check-label" for="gridCheck"><a href="#" class=""><?php echo e(Str::ucfirst( $v)); ?> </a> </label>
                            </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u717518117/domains/liquorroad.in/public_html/admin/resources/views/users/show.blade.php ENDPATH**/ ?>