<?php

namespace App\Http\Controllers;
use Illuminate\Validation\ValidationException;
use App\Models\ProjectContacts;
use Illuminate\Http\Request;

class AjaxController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function getContactPerson(){
        $data = [
            'contacts' => ProjectContacts::pluck('name', 'id'),
            'status' => 'success'
        ];
        return response()->json($data);
    }
}
