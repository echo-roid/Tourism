<?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="sectionbackground ">
    <div>
        <?php echo $__env->yieldContent("content"); ?>
    </div>
</section>





<?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
<?php echo $__env->make('layouts.rightsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u717518117/domains/liquorroad.in/public_html/admin/resources/views/layouts/app.blade.php ENDPATH**/ ?>