<?php if(Auth::user()): ?>
<div class="rightbar">
    <div class="mb-3 text-center mt-4">
        <a href="<?php echo e(url('/home')); ?>"><img src="<?php echo e(asset('public/assets/sideorangeicon.png')); ?>" alt="" class="orangeiconleft"></a>
    </div>
        <ul class="iconbar">
                <!--<li  class="activeliicon"> <a href="./second.html"> <img src="<?php echo e(asset('public/assets/ficon1.png')); ?>" alt=""></a></li>-->
                <li><a href="<?php echo e(url('/home')); ?>"><img src="<?php echo e(asset('public/assets/ficon2.png')); ?>" alt=""></a></li>
                <!--<li><a href="./allfrom.html"> <img src="<?php echo e(asset('assets/ficon3.png')); ?>" alt=""></a></li>-->
                <!--<li><a href="./travelerslist.html"><img src="<?php echo e(asset('assets/ficon4.png')); ?>" alt=""></a></li>-->
                <!--<li><a href="./contract.html"><img src="<?php echo e(asset('assets/ficon5.png')); ?>" alt=""></a></li>-->
                <li><a href="<?php echo e(route('company.project')); ?>"><img src="<?php echo e(asset('public/assets/ficon6.png')); ?>" alt=""></a></li>
                 <!--<li><a href="<?php echo e(url('/project')); ?>"><img src="<?php echo e(asset('assets/ficon6.png')); ?>" alt=""></a></li>-->
                
                <li><a href="<?php echo e(route('company.contacts')); ?>"><i class="fa-solid fa-address-book"></i></a></li>
                <li><a href="<?php echo e(route('roles.index')); ?>"><i class="fa-solid fa-gear"></i></a></li>
                <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="fa fa-sign-out"></i></a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>    
                </li>
        </ul>
</div>
<?php endif; ?><?php /**PATH /home/u717518117/domains/liquorroad.in/public_html/admin/resources/views/layouts/rightsidebar.blade.php ENDPATH**/ ?>