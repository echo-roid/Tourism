<?php echo e($slot); ?>

<?php /**PATH /home/u717518117/domains/liquorroad.in/public_html/admin/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>