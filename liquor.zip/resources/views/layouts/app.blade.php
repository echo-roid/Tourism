@include("layouts.header")

<section class="sectionbackground ">
    <div>
        @yield("content")
    </div>
</section>



@extends('layouts.rightsidebar')

@include("layouts.footer")

    