<!DOCTYPE html>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Razorpay Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            width: 900px;
            height: 500px;
            background-color: white;
            display: flex;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            overflow: hidden;
        }

        .left-section {
            flex: 1;
            background-color: #0a1f44;
            color: white;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: left;
        }

        .left-section h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .left-section p {
            font-size: 16px;
            margin-bottom: 20px;
        }

        .left-section img {
            width: 200px;
            margin-bottom: 20px;
        }

        .right-section {
            flex: 1;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .right-section h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .form-group button {
            width: 100%;
            padding: 12px;
            background-color: #0066ff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #0052cc;
        }

        .or-divider {
            margin: 20px 0;
            text-align: center;
            position: relative;
        }

        .or-divider:before, .or-divider:after {
            content: "";
            position: absolute;
            top: 50%;
            width: 40%;
            height: 1px;
            background: #ddd;
        }

        .or-divider:before {
            left: 0;
        }

        .or-divider:after {
            right: 0;
        }

        .or-divider span {
            padding: 0 10px;
            background: #fff;
            color: #aaa;
        }

        .google-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 12px;
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
        }

        .google-btn img {
            margin-right: 10px;
        }

        .google-btn:hover {
            background-color: #f7f7f7;
        }
        .invalid-feedback{
            color: red;
        }
    </style>
</head>
<body>

    <div class="container">
        <!-- Left side with background and info -->
        <div class="left-section">
            <h2>Razorpay Magic Checkout</h2>
            <img src="https://via.placeholder.com/200" alt="Magic Checkout">
            <p>⚡ Boost buyer intent, reduce fake orders, & increase pre-paid order share on Magic Checkout!</p>
            <a href="#" style="color: white; text-decoration: underline;">Explore Magic Checkout →</a>
            <p style="margin-top: 20px;">Need help? <a href="#" style="color: white; text-decoration: underline;">Contact Us</a></p>
        </div>

        <!-- Right side with form -->
        <div class="right-section">
            <h2>Login to Dashboard</h2>
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group " hidden>
                    <input type="text" placeholder="Enter OTP">
                </div>
                <div class="form-group">
                    <button>Next</button>
                </div>
            </form>
        </div>
    </div>

</body>
</html><?php /**PATH /home/u717518117/domains/liquorroad.in/public_html/admin/resources/views/login.blade.php ENDPATH**/ ?>