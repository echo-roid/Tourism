

<?php $__env->startSection('title',"Roles"); ?>

<?php $__env->startSection('content'); ?>
    <section style="min-height: 550px">
        <div class="p-3 boxshadowgernet backbluelight">
                <ul class=" d-flex align-items-center mb-0 list-unstyled">
                    <li class="font500 font13">
                        <a href="<?php echo e(route('home')); ?>">Back</a>
                    </li>
                    <li class="mx-2">
                        <img src="<?php echo e(asset('public/assets/rightarrow.png')); ?>" alt="">
                    </li>
                    <li class="colorblue font500 font13 ms-4">
                        Admin Setting  
                    </li>
                    <li class="mx-2">
                        <img src="<?php echo e(asset('public/assets/rightarrow.png')); ?>" alt="">
                    </li>
                    <li class="font13 font500">Role</li>
                </ul>
        </div>

        <div class="boxhalf boxshadowgernet mt-2 p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <div class="d-flex align-items-center">
                    <img src="./assets/menwithkey.png" width="20" alt="">
                    <p class="font15 colorblue font500 mb-0 ms-2">Roles and permission</p>
                </div>
                <div>
                    
                    <a class="createrole" href="<?php echo e(route('users.index')); ?>"> Manage Users</a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>
                        <a class="createrole" href="<?php echo e(route('roles.create')); ?>"> Create Role</a>
                    <?php endif; ?>
                </div>
                </div>
                
                <div>
                    <p class="font13 colorblue">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae dolores quasi doloremque voluptatibus ab aliquid <br> voluptas Lorem ipsum dolor sit amet  consectetur adipisicing elit. Illo quaerat vitae minima repellendus maiores <br> autem, mollitia, quo ut temporibus br, ullam ipsam commodi? Repudiandae magni, explicabo quas possimus <br>  ipsam veritatis soluta. nesciunt Aspernatur vel velit est excepturi maiores, quibusdam expedita et, voluptatum .</p>
                </div>

                <div>

                <button class="learmore">
                    <img src="./assets/ques.png" width="15" alt="">
                    Learn more
                </button>
                </div>
        </div>

        <div class="boxhalf mt-3 boxshadowgernet">

            <div class="p-2  musdardcolor">
                <p class="mb-0 font13 ">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nisi impedit error veritatis nihil, rerum quasi ducimus alias officia est ut non unde modi ipsa, culpa aspernatur quos. Reprehenderit, id nam!</p>
        </div>
        <div class="">
            <table class="Contract w-100">
                <tr class="backgroundlightblue ">
                    <th><p class=" p-2 mb-0">Sr.</p></th>
                    <th><p class=" p-2 mb-0">Roles</p></th>
                    <th><p class=" p-2 mb-0">liceness</p></th>
                    
                    <th><p class=" p-2 mb-0">CREATED</p></th>
                    <th><p class=" p-2 mb-0">UPDATED </p></th>
                    <th>Action</th>
                    
                </tr>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="font12 px-2 py-2"> <?php echo e(++$i); ?></td>
                    <td class="font12 px-2 py-2"> <?php echo e($role->name); ?></td>
                    <td class="font12 px-2 py-2">700</td>
                    
                    <td class="font12 px-2 py-2"><?php echo e(date("Y-m-d",strtotime($role->created_at))); ?></td>
                    <td class="font12 px-2 py-2"><?php echo e(date("Y-m-d",strtotime($role->updated_at))); ?></td>
                    <td>
                        <a class="createrole" href="<?php echo e(route('roles.show',$role->id)); ?>">Show</a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                            <a class="createrole" href="<?php echo e(route('roles.edit',$role->id)); ?>">Edit</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                                <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $role->id],'style'=>'display:inline']); ?>

                                <?php echo Form::submit('Delete', ['class' => 'createrole']); ?>

                                <?php echo Form::close(); ?>

                            <?php endif; ?>

                        
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
                <?php echo $roles->render(); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u717518117/domains/liquorroad.in/public_html/admin/resources/views/roles/role_list.blade.php ENDPATH**/ ?>