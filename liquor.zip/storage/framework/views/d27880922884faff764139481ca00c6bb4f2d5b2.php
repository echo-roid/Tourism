<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/u717518117/domains/liquorroad.in/public_html/admin/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>